package com.algoda.word.model;


public class WordDTO {
    String word;
    String meaninga;
    String meaningb;
    String meaningc;
    String similar_worda;
    String similar_wordb;
    String similar_wordc;
    int day;

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getMeaninga() {
        return meaninga;
    }

    public void setMeaninga(String meaninga) {
        this.meaninga = meaninga;
    }

    public String getMeaningb() {
        return meaningb;
    }

    public void setMeaningb(String meaningb) {
        this.meaningb = meaningb;
    }

    public String getMeaningc() {
        return meaningc;
    }

    public void setMeaningc(String meaningc) {
        this.meaningc = meaningc;
    }

    public String getSimilar_worda() {
        return similar_worda;
    }

    public void setSimilar_worda(String similar_worda) {
        this.similar_worda = similar_worda;
    }

    public String getSimilar_wordb() {
        return similar_wordb;
    }

    public void setSimilar_wordb(String similar_wordb) {
        this.similar_wordb = similar_wordb;
    }

    public String getSimilar_wordc() {
        return similar_wordc;
    }

    public void setSimilar_wordc(String similar_wordc) {
        this.similar_wordc = similar_wordc;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
    
    
}