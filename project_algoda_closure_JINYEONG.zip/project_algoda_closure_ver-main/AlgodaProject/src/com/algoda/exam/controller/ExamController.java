package com.algoda.exam.controller;

import com.algoda.voc.model.MyVocDAO;
import com.algoda.voc.model.MyVocDTO;
import com.algoda.word.model.WordADAO;
import com.algoda.word.model.WordBDAO;
import com.algoda.word.model.WordCDAO;
import com.algoda.word.model.WordDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@WebServlet("/exam.do")
public class ExamController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ExamController() {
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //int level = Integer.parseInt(req.getParameter("level"));
//        int day = Integer.parseInt(req.getParameter("day"));
        HttpSession session = req.getSession();
        String examtype = (String) session.getAttribute("examType");

        if (examtype.equals("myvoc")) {
            int randomnumber[] = new int[10];
            Random random = new Random();
            List<MyVocDTO> myvocdtoList = new ArrayList<MyVocDTO>();
            MyVocDAO myvocdao = new MyVocDAO();

            List<MyVocDTO> wordList = myvocdao.selectExamList();

            for (int i = 0; i < 10; i++) {
                randomnumber[i] = random.nextInt(wordList.size());
                for (int j = 0; j < i; j++) {
                    if (randomnumber[i] == randomnumber[j]) i--;
                }
            }
            for (int i = 0; i < 10; i++) {
                myvocdtoList.add(wordList.get(randomnumber[i]));
            }

            session.setAttribute("examLists", myvocdtoList);


            req.setAttribute("method", "vol");
            req.getRequestDispatcher("/exam/Exam.jsp").forward(req, resp);
        } else {
            int level = (int) session.getAttribute("wordLevelQuiz");
            int day = (int) session.getAttribute("wordDayQuiz");
            int randomnumber[] = new int[10];
            Random random = new Random();
            List<WordDTO> worddtoList = new ArrayList<WordDTO>();
            WordDTO worddto = new WordDTO();
            worddto.setDay(day);
            if (level == 1) {
                WordADAO wordadao = new WordADAO();

                List<WordDTO> wordAList = wordadao.getWordList(worddto);
                randomQ(randomnumber, random, worddtoList, wordAList);
            } else if (level == 2) {
                WordBDAO wordbdao = new WordBDAO();

                List<WordDTO> wordBList = wordbdao.getWordList(worddto);
                randomQ(randomnumber, random, worddtoList, wordBList);
            } else if (level == 3) {
                WordCDAO wordcdao = new WordCDAO();

                List<WordDTO> wordCList = wordcdao.getWordList(worddto);
                randomQ(randomnumber, random, worddtoList, wordCList);
            }
            session.setAttribute("level", level);
            session.setAttribute("examLists", worddtoList);

            req.getRequestDispatcher("/exam/Exam.jsp").forward(req, resp);
        }
    }

    private void randomQ(int[] randomnumber, Random random, List<WordDTO> worddtoList, List<WordDTO> wordList) {
        for (int i = 0; i < 10; i++) {
            randomnumber[i] = random.nextInt(wordList.size());
            for (int j = 0; j < i; j++) {
                if (randomnumber[i] == randomnumber[j]) i--;
            }
        }
        for (int i = 0; i < 10; i++) {
            worddtoList.add(wordList.get(randomnumber[i]));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        int randomnumber[] = new int[10];
        Random random = new Random();
        List<MyVocDTO> myvocdtoList = new ArrayList<MyVocDTO>();
        MyVocDAO myvocdao = new MyVocDAO();

        List<MyVocDTO> wordList = myvocdao.selectExamList();

        for (int i = 0; i < 10; i++) {
            randomnumber[i] = random.nextInt(wordList.size());
            for (int j = 0; j < i; j++) {
                if (randomnumber[i] == randomnumber[j]) i--;
            }
        }
        for (int i = 0; i < 10; i++) {
            myvocdtoList.add(wordList.get(randomnumber[i]));
        }

        session.setAttribute("examLists", myvocdtoList);

        session.setAttribute("examType", "myvoc");

        req.getRequestDispatcher("/exam/Exam.jsp").forward(req, resp);
    }
}