package com.algoda.voc.model;

public class MyVocDTO {

	private String word;
	
	private String	 MEANINGA; 
	private String   MEANINGB;  
	private String   MEANINGC;  
	private String   SIMILAR_WORDA;  
	private String   SIMILAR_WORDB;  
	private String   SIMILAR_WORDC;
	private int WORD_LEVEL;
	private int   DAY;
	private String   ID;  
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getMEANINGA() {
		return MEANINGA;
	}
	public void setMEANINGA(String mEANINGA) {
		MEANINGA = mEANINGA;
	}
	public String getMEANINGB() {
		return MEANINGB;
	}
	public void setMEANINGB(String mEANINGB) {
		MEANINGB = mEANINGB;
	}
	public String getMEANINGC() {
		return MEANINGC;
	}
	public void setMEANINGC(String mEANINGC) {
		MEANINGC = mEANINGC;
	}
	public String getSIMILAR_WORDA() {
		return SIMILAR_WORDA;
	}
	public void setSIMILAR_WORDA(String sIMILAR_WORDA) {
		SIMILAR_WORDA = sIMILAR_WORDA;
	}
	public String getSIMILAR_WORDB() {
		return SIMILAR_WORDB;
	}
	public void setSIMILAR_WORDB(String sIMILAR_WORDB) {
		SIMILAR_WORDB = sIMILAR_WORDB;
	}
	public String getSIMILAR_WORDC() {
		return SIMILAR_WORDC;
	}
	public void setSIMILAR_WORDC(String sIMILAR_WORDC) {
		SIMILAR_WORDC = sIMILAR_WORDC;
	}
	public int getWORD_LEVEL() {
		return WORD_LEVEL;
	}
	public void setWORD_LEVEL(int wORD_LEVEL) {
		WORD_LEVEL = wORD_LEVEL;
	}
	public int getDAY() {
		return DAY;
	}
	public void setDAY(int dAY) {
		DAY = dAY;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	
	
}
