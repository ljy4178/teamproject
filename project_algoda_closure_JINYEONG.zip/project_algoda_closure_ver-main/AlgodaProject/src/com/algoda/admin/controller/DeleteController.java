package com.algoda.admin.controller;

import com.algoda.word.model.WordADAO;
import com.algoda.word.model.WordBDAO;
import com.algoda.word.model.WordCDAO;
import com.algoda.word.model.WordDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/delete.do")
public class DeleteController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public DeleteController() {
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String word = req.getParameter("word");
        int level = Integer.parseInt(req.getParameter("level"));
        System.out.println(word);
        System.out.println(level);
        if (level == 1) {
            WordADAO dao = new WordADAO();
            WordDTO dto = new WordDTO();
            dto.setWord(word);
            dao.deleteWordA(dto);

            alertLocation(resp, "삭제되었습니다.", "admin.do?adminlevel=" + level);
        } else if (level == 2) {
            WordBDAO dao = new WordBDAO();
            WordDTO dto = new WordDTO();
            dto.setWord(word);
            dao.deleteWord(dto);

            alertLocation(resp, "삭제되었습니다.", "admin.do?adminlevel=" + level);
        } else if (level == 3) {
            WordCDAO dao = new WordCDAO();
            WordDTO dto = new WordDTO();
            dto.setWord(word);
            dao.deleteWord(dto);

            alertLocation(resp, "삭제되었습니다.", "admin.do?adminlevel=" + level);
        }

    }

    private void alertLocation(HttpServletResponse resp, String msg, String url) {
        try {
            resp.setContentType("text/html;charset=UTF-8");
            PrintWriter writer = resp.getWriter();
            String script = ""
                    + "<script>"
                    + "    alert('" + msg + "');"
                    + "    location.href='" + url + "';"
                    + "</script>";
            writer.print(script);
        } catch (Exception e) {
        }
    }

}