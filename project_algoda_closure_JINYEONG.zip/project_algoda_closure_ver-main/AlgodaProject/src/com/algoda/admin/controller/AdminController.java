package com.algoda.admin.controller;

import com.algoda.word.model.WordADAO;
import com.algoda.word.model.WordBDAO;
import com.algoda.word.model.WordCDAO;
import com.algoda.word.model.WordDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin.do")
public class AdminController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public AdminController() {
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	req.setCharacterEncoding("utf-8");
        HttpSession session = req.getSession();
        List<WordDTO> worddtoList = null;
        String section = "미정";

        int level = Integer.parseInt(req.getParameter("adminlevel"));
        if (level == 1) {
            section = "중등 영단어";
            WordADAO wordadao = new WordADAO();
            worddtoList = wordadao.getWordAList();
        } else if (level == 2) {
            section = "수능 영단어";
            WordBDAO wordbdao = new WordBDAO();
            worddtoList = wordbdao.getWordBList();
        } else if (level == 3) {
            section = "직장인 영단어";
            WordCDAO wordcdao = new WordCDAO();
            worddtoList = wordcdao.getWordCList();
        }
        req.setAttribute("level", level);
        req.setAttribute("section", section);
        req.setAttribute("adminWords", worddtoList);
        req.getRequestDispatcher("/admin/Admin.jsp").forward(req, resp);
    }
}
