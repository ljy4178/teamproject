package com.algoda.main.controller;

import com.algoda.member.model.MemberDAO;
import com.algoda.member.model.MemberDTO;
import com.algoda.word.model.WordADAO;
import com.algoda.word.model.WordBDAO;
import com.algoda.word.model.WordCDAO;
import com.algoda.word.model.WordDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@WebServlet("/main.do")
public class MainController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public MainController() {
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //int level = Integer.parseInt(req.getParameter("level"));
//        int day = Integer.parseInt(req.getParameter("day"));
        int day = 1;
        int randomnumber;
        Random random = new Random();
        List<WordDTO> worddtoList = new ArrayList<WordDTO>();
        WordDTO worddto = new WordDTO();
        worddto.setDay(day);
        WordADAO wordadao = new WordADAO();
        WordBDAO wordbdao = new WordBDAO();
        WordCDAO wordcdao = new WordCDAO();

        List<WordDTO> wordList = wordadao.getWordList(worddto);
        randomnumber = random.nextInt(wordList.size());
        worddtoList.add(wordList.get(randomnumber));

        wordList = wordbdao.getWordList(worddto);
        randomnumber = random.nextInt(wordList.size());
        worddtoList.add(wordList.get(randomnumber));

        wordList = wordcdao.getWordList(worddto);
        randomnumber = random.nextInt(wordList.size());
        worddtoList.add(wordList.get(randomnumber));

        HttpSession session = req.getSession();
        session.setAttribute("Todaywords", worddtoList);

        // 유저 이름 세션에 보내기
        MemberDAO memberdao = new MemberDAO();
        String id = (String) session.getAttribute("id");
        String pwd = (String) session.getAttribute("pwd");
        MemberDTO memberdto = memberdao.selectloginMember(id, pwd);
        String username = memberdto.getName();
        session.setAttribute("username", username);

        resp.sendRedirect("word/Main.jsp");
    }
}