package com.algoda.member.model;


public class MemberDTO {
	   private String id;
	   private String name;
	   private String pwd;
	   private String email;
	   private String tel;
	   private int hint;
	   private String hint_asw;
	   private int scorea;
	   private int scoreb;
	   private int scorec;
	   private int acount;
	   private int bcount;
	   private int ccount;
	
   public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public int getHint() {
		return hint;
	}
	public void setHint(int hint) {
		this.hint = hint;
	}
	public String getHint_asw() {
		return hint_asw;
	}
	public void setHint_asw(String hint_asw) {
		this.hint_asw = hint_asw;
	}
	public int getScorea() {
		return scorea;
	}
	public void setScorea(int scorea) {
		this.scorea = scorea;
	}
	public int getScoreb() {
		return scoreb;
	}
	public void setScoreb(int scoreb) {
		this.scoreb = scoreb;
	}
	public int getScorec() {
		return scorec;
	}
	public void setScorec(int scorec) {
		this.scorec = scorec;
	}
	public int getAcount() {
		return acount;
	}
	public void setAcount(int acount) {
		this.acount = acount;
	}
	public int getBcount() {
		return bcount;
	}
	public void setBcount(int bcount) {
		this.bcount = bcount;
	}
	public int getCcount() {
		return ccount;
	}
	public void setCcount(int ccount) {
		this.ccount = ccount;
	}

	
}

